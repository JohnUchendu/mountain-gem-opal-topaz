# JKTL Games

A minimal daily puzzle MVP for `game.jktl.com.ng`, built with Next.js App Router, TypeScript, Tailwind CSS, and Neon PostgreSQL using plain SQL (no ORM).

## Included

- Home page and game navigation
- Word Guess: five-letter daily word with six attempts
- Word Groups: four groups of four related words
- Word Scramble: daily anagram with server-side answer checking
- Daily Riddle: daily clue with configurable accepted answers
- Lagos-time daily puzzle lookup
- Admin page to create/publish daily challenges
- PostgreSQL schema and seed command
- Basic unit tests for word scoring and group validation
- Guest play; Word Guess progress is saved locally in the browser

## Requirements

- Node.js 20.9+ (current Node LTS recommended)
- npm
- A Neon PostgreSQL database
- A Vercel account for deployment

## Local setup

1. Extract the ZIP and open the `jktl-games` folder in VS Code.
2. Install dependencies:

   ```bash
   npm install
   ```

3. Create a local environment file:

   ```bash
   cp .env.example .env.local
   ```

4. Create a Neon project/database and copy its connection string into `DATABASE_URL` in `.env.local`. Replace `ADMIN_TOKEN` with a long random secret.

5. Create the database tables:

   ```bash
   npm run db:seed
   ```

6. Start the development server:

   ```bash
   npm run dev
   ```

7. Open `http://localhost:3000`.

## Publish your first puzzles

1. Open `/admin`.
2. Enter the same `ADMIN_TOKEN` value from `.env.local`.
3. Choose today's date in Nigeria time.
4. For Word Guess, provide a five-letter answer.
5. For Word Groups, use the sample JSON in the admin page or replace it with your own 16 unique words and four groups. For Word Scramble, enter a 4–12 letter answer and optionally a scrambled arrangement. For Daily Riddle, enter a clue, answer and optional accepted variants.
6. Publish and save. The puzzle pages read published content for the current Lagos date.

**Important:** Do not publish an answer in public client-side code. The secret answer is stored in the database and checked on the server.

## Deploy to Vercel

1. Push the extracted project to a new GitHub repository.
2. Import the repository into Vercel.
3. Add `DATABASE_URL`, `ADMIN_TOKEN`, and `NEXT_PUBLIC_SITE_URL` to Vercel Project Settings → Environment Variables. Use the Neon pooled connection string for serverless production.
4. Deploy.
5. Attach `game.jktl.com.ng` in Vercel → Project Settings → Domains, then configure the DNS records Vercel displays at your domain provider.

## Commands

```bash
npm run dev
npm run build
npm run lint
npm test
npm run db:seed
```

## MVP limitations / production checklist

- Admin uses a shared token header, not a complete authentication system. Add proper admin auth before inviting editors.
- Word Guess browser state is local to the device; server-side result persistence and cross-device accounts are not yet implemented.
- Add rate limiting and abuse protection to game APIs.
- Add accessibility review, analytics/consent handling, monitoring, backups and a content moderation/review process.
- Word Groups currently tracks solved groups in component state only; add persistence and share-result functionality before a wider launch.
- Scramble and Riddle attempts are not persisted across devices yet.
- Add a daily-puzzle publishing workflow and verify all puzzle answers before publication.

This is a starter codebase. Run the commands above and test it in your own environment before treating it as production-ready.
