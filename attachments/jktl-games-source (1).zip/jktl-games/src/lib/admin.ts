import { timingSafeEqual } from "node:crypto";
import { headers } from "next/headers";

function safeEqual(a: string, b: string) {
  const aa = Buffer.from(a);
  const bb = Buffer.from(b);
  return aa.length === bb.length && timingSafeEqual(aa, bb);
}

export async function isAdminRequest() {
  const token = process.env.ADMIN_TOKEN;
  if (!token) return false;
  const headerStore = await headers();
  const provided = headerStore.get("x-admin-token") ?? "";
  return safeEqual(provided, token);
}
