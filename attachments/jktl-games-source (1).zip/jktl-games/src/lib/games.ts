export type GuessMark = "correct" | "present" | "absent";

export function scoreGuess(guess: string, answer: string): GuessMark[] {
  const g = guess.toUpperCase().split("");
  const a = answer.toUpperCase().split("");
  const marks: GuessMark[] = Array(g.length).fill("absent");
  const remaining = new Map<string, number>();

  for (let i = 0; i < g.length; i++) {
    if (g[i] === a[i]) marks[i] = "correct";
    else remaining.set(a[i], (remaining.get(a[i]) ?? 0) + 1);
  }
  for (let i = 0; i < g.length; i++) {
    if (marks[i] === "correct") continue;
    const count = remaining.get(g[i]) ?? 0;
    if (count > 0) {
      marks[i] = "present";
      remaining.set(g[i], count - 1);
    }
  }
  return marks;
}

export type WordGroup = { label: string; color: string; words: string[] };

export function validateGroupPuzzle(value: unknown): value is { words: string[]; groups: WordGroup[] } {
  if (!value || typeof value !== "object") return false;
  const candidate = value as { words?: unknown; groups?: unknown };
  if (!Array.isArray(candidate.words) || !Array.isArray(candidate.groups)) return false;
  if (candidate.words.length !== 16 || candidate.groups.length !== 4) return false;
  if (!candidate.words.every((w) => typeof w === "string" && w.trim().length > 0)) return false;
  if (new Set(candidate.words.map((w) => w.toUpperCase())).size !== 16) return false;
  const allGroupWords: string[] = [];
  for (const group of candidate.groups) {
    if (!group || typeof group !== "object") return false;
    const g = group as Partial<WordGroup>;
    if (typeof g.label !== "string" || typeof g.color !== "string" ||
        !Array.isArray(g.words) || g.words.length !== 4 ||
        !g.words.every((w) => typeof w === "string")) return false;
    allGroupWords.push(...g.words);
  }
  return allGroupWords.length === 16 &&
    new Set(allGroupWords.map((w) => w.toUpperCase())).size === 16 &&
    allGroupWords.every((w) => candidate.words!.some((x) => x.toUpperCase() === w.toUpperCase()));
}
