import type { ButtonHTMLAttributes } from "react";
import { clsx } from "clsx";

type Props = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "solid" | "outline" | "ghost" };
export function Button({ className, variant = "solid", ...props }: Props) {
  return <button className={clsx(
    "inline-flex items-center justify-center rounded-full px-5 py-3 text-sm font-semibold transition disabled:cursor-not-allowed disabled:opacity-40",
    variant === "solid" && "bg-neutral-900 text-white hover:bg-neutral-700",
    variant === "outline" && "border border-neutral-300 bg-white hover:bg-neutral-100",
    variant === "ghost" && "hover:bg-neutral-100",
    className,
  )} {...props} />;
}
