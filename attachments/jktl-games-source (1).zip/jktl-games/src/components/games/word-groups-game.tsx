"use client";

import { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";

type Challenge = { puzzle_data: { words: string[] }; title: string; instructions: string };
type SolvedGroup = { words: string[]; label: string; color: string };

export function WordGroupsGame() {
  const [date, setDate] = useState("");
  const [challenge, setChallenge] = useState<Challenge | null>(null);
  const [selected, setSelected] = useState<string[]>([]);
  const [solved, setSolved] = useState<SolvedGroup[]>([]);
  const [mistakes, setMistakes] = useState(0);
  const [message, setMessage] = useState("Loading today’s puzzle…");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    const d = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Africa/Lagos", year: "numeric", month: "2-digit", day: "2-digit",
    }).format(new Date());
    setDate(d);
    fetch("/api/challenges").then(async (r) => {
      const data = await r.json() as { challenges?: { game_type: string; title: string; instructions: string; puzzle_data: Challenge["puzzle_data"] }[]; error?: string };
      if (!r.ok) throw new Error(data.error ?? "Could not load puzzle.");
      const item = data.challenges?.find((c) => c.game_type === "word_groups");
      if (!item) throw new Error("No Word Groups puzzle published for today yet.");
      setChallenge(item); setMessage("");
    }).catch((e: unknown) => setMessage(e instanceof Error ? e.message : "Could not load puzzle."));
  }, []);

  const words = challenge?.puzzle_data.words ?? [];
  const toggle = (word: string) => {
    if (solved.some((g) => g.words.includes(word))) return;
    setSelected((current) => current.includes(word) ? current.filter((w) => w !== word) :
      current.length < 4 ? [...current, word] : current);
  };

  async function check() {
    if (selected.length !== 4 || busy) return;
    setBusy(true); setMessage("");
    try {
      const response = await fetch("/api/games/word-groups/check", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, words: selected }),
      });
      const data = await response.json() as { correct?: boolean; group?: string; color?: string; error?: string };
      if (!response.ok) throw new Error(data.error ?? "Could not check group.");
      if (data.correct) {
        setSolved((current) => [...current, { words: selected, label: data.group ?? "Matched group", color: data.color ?? "#d9f99d" }]);
        setMessage("Nice connection!"); setSelected([]);
      } else {
        setMistakes((n) => n + 1); setMessage("Not quite. Try a different connection.");
      }
    } catch (e) { setMessage(e instanceof Error ? e.message : "Could not check those words."); }
    finally { setBusy(false); }
  }

  if (!challenge) return <section className="mx-auto max-w-2xl px-5 py-14"><h1 className="text-4xl font-black">Word Groups</h1><p className="mt-4 text-neutral-600">{message}</p></section>;
  const remaining = words.filter((w) => !solved.some((g) => g.words.includes(w)));
  return <section className="mx-auto max-w-2xl px-5 py-10">
    <p className="text-xs font-bold uppercase tracking-[.2em] text-neutral-500">Daily puzzle / 02</p>
    <h1 className="mt-3 text-4xl font-black tracking-tight">{challenge.title || "Word Groups"}</h1>
    <p className="mt-3 text-neutral-600">{challenge.instructions || "Find four groups of four words that share something in common."}</p>
    <div className="mt-6 space-y-2">
      {solved.map((group) => <div key={group.label} className="rounded-2xl p-4 text-center" style={{ backgroundColor: group.color }}>
        <p className="font-black">{group.label}</p><p className="mt-1 text-sm">{group.words.join(" · ")}</p>
      </div>)}
    </div>
    <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
      {remaining.map((word) => <button key={word} onClick={() => toggle(word)} aria-pressed={selected.includes(word)}
        className={`min-h-20 rounded-xl border px-2 text-sm font-bold transition ${selected.includes(word) ? "border-neutral-900 bg-neutral-900 text-white" : "border-neutral-200 bg-white hover:border-neutral-400"}`}>{word}</button>)}
    </div>
    <p className="mt-4 text-sm text-neutral-500">Selected: {selected.length}/4 · Mistakes: {mistakes}</p>
    <div className="mt-4 flex flex-wrap gap-2"><Button onClick={() => void check()} disabled={selected.length !== 4 || busy}>Submit group</Button><Button variant="outline" onClick={() => setSelected([])}>Deselect all</Button><Button variant="ghost" onClick={() => window.location.href = "/"}>All games</Button></div>
    <p aria-live="polite" className="mt-4 min-h-6 text-sm text-neutral-600">{solved.length === 4 ? "Perfect solve. See you tomorrow!" : message}</p>
  </section>;
}
