"use client";

import { useEffect, useMemo, useState } from "react";
import { Button } from "@/components/ui/button";

type Mark = "correct" | "present" | "absent";
type Row = { guess: string; marks: Mark[] };

export function WordGuessGame() {
  const [date, setDate] = useState("");
  const [guess, setGuess] = useState("");
  const [rows, setRows] = useState<Row[]>([]);
  const [message, setMessage] = useState("Loading today’s puzzle…");
  const [done, setDone] = useState(false);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const d = new Intl.DateTimeFormat("en-CA", {
      timeZone: "Africa/Lagos", year: "numeric", month: "2-digit", day: "2-digit",
    }).format(new Date());
    setDate(d);
    try {
      const saved = localStorage.getItem(`jktl-word-guess-${d}`);
      if (saved) {
        const parsed = JSON.parse(saved) as { rows?: Row[]; done?: boolean };
        setRows(parsed.rows ?? []);
        setDone(parsed.done ?? false);
      }
    } catch { /* ignore stale local state */ }
    setReady(true);
    setMessage("");
  }, []);

  useEffect(() => {
    if (ready && date) localStorage.setItem(`jktl-word-guess-${date}`, JSON.stringify({ rows, done }));
  }, [date, rows, done, ready]);

  const won = useMemo(() => rows.some((r) => r.marks.every((m) => m === "correct")), [rows]);
  async function submit() {
    if (guess.length !== 5 || done || rows.length >= 6) return;
    setMessage("");
    try {
      const response = await fetch("/api/games/word-guess/guess", {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ guess, date }),
      });
      const data = await response.json() as { error?: string; marks?: Mark[]; solved?: boolean };
      if (!response.ok || !data.marks) { setMessage(data.error ?? "Could not check that word."); return; }
      const next = [...rows, { guess: guess.toUpperCase(), marks: data.marks }];
      setRows(next); setGuess("");
      if (data.solved) { setDone(true); setMessage("Brilliant. You got it!"); }
      else if (next.length >= 6) { setDone(true); setMessage("That’s six tries. Come back for tomorrow’s puzzle."); }
    } catch { setMessage("Network error. Please try again."); }
  }

  return <section className="mx-auto max-w-xl px-5 py-10">
    <p className="text-xs font-bold uppercase tracking-[.2em] text-neutral-500">Daily puzzle / 01</p>
    <h1 className="mt-3 text-4xl font-black tracking-tight">Word Guess</h1>
    <p className="mt-3 text-neutral-600">Find the five-letter word in six tries. Green is right, yellow is in the word, grey is not in the word.</p>
    <div className="mx-auto mt-8 grid max-w-[320px] gap-2">
      {Array.from({ length: 6 }, (_, rowIndex) => {
        const row = rows[rowIndex];
        return <div key={rowIndex} className="grid grid-cols-5 gap-2">
          {Array.from({ length: 5 }, (_, colIndex) => {
            const letter = row?.guess[colIndex] ?? (rowIndex === rows.length ? guess[colIndex] : "") ?? "";
            const mark = row?.marks[colIndex];
            const color = mark === "correct" ? "bg-lime-600 text-white border-lime-600" :
              mark === "present" ? "bg-amber-400 text-neutral-900 border-amber-400" :
              mark === "absent" ? "bg-neutral-500 text-white border-neutral-500" :
              letter ? "border-neutral-500 bg-white" : "border-neutral-200 bg-white";
            return <div key={colIndex} className={`flex aspect-square items-center justify-center rounded-xl border-2 text-2xl font-black ${color}`}>{letter}</div>;
          })}
        </div>;
      })}
    </div>
    <form className="mx-auto mt-6 flex max-w-[320px] gap-2" onSubmit={(e) => { e.preventDefault(); void submit(); }}>
      <input aria-label="Your five-letter guess" value={guess} onChange={(e) => setGuess(e.target.value.replace(/[^a-z]/gi, "").slice(0, 5).toUpperCase())}
        disabled={done || rows.length >= 6 || !ready} autoComplete="off" maxLength={5}
        className="min-w-0 flex-1 rounded-full border border-neutral-300 bg-white px-5 py-3 uppercase tracking-[.25em] outline-none focus:border-neutral-800" placeholder="GUESS" />
      <Button type="submit" disabled={guess.length !== 5 || done || !ready}>Enter</Button>
    </form>
    <p aria-live="polite" className="mt-4 min-h-6 text-center text-sm text-neutral-600">{message}</p>
    <div className="mt-8 flex justify-center"><Button variant="outline" onClick={() => window.location.href = "/"}>Back to all games</Button></div>
  </section>;
}
