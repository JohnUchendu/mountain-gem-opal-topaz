import Link from "next/link";
import { GameHeader } from "@/components/shared/game-header";
const games = [
 { href: "/play/word-guess", number: "01", name: "Word Guess", detail: "Six tries. One five-letter word.", tag: "DAILY WORD" },
 { href: "/play/word-groups", number: "02", name: "Word Groups", detail: "Find four connections hiding in sixteen words.", tag: "FIND THE LINK" },
 { href: "/play/word-scramble", number: "03", name: "Word Scramble", detail: "Unscramble the letters to reveal today’s word.", tag: "UNMIX THE LETTERS" },
 { href: "/play/daily-riddle", number: "04", name: "Daily Riddle", detail: "One clever clue. Can you solve it?", tag: "THINK SIDEWAYS" },
];
export default function HomePage() {
 const today = new Intl.DateTimeFormat("en", { dateStyle: "full", timeZone: "Africa/Lagos" }).format(new Date());
 return <main className="min-h-screen"><GameHeader/><section className="mx-auto max-w-5xl px-5 pb-20 pt-14 md:px-8 md:pt-24">
 <p className="text-xs font-bold uppercase tracking-[.22em] text-neutral-500">A daily ritual for curious minds</p><h1 className="mt-5 max-w-3xl text-5xl font-black leading-[.98] tracking-tight md:text-7xl">Small games.<br/>Big brain energy.</h1>
 <p className="mt-6 max-w-xl text-lg leading-8 text-neutral-600">A few minutes, a fresh challenge, and that satisfying moment when it clicks.</p><div className="mt-8 inline-flex rounded-full border border-neutral-200 bg-white px-4 py-2 text-sm text-neutral-600">{today}</div>
 <div className="mt-14 grid gap-4 sm:grid-cols-2">{games.map(g=><Link key={g.href} href={g.href} className="group rounded-3xl border border-neutral-200 bg-white p-7 transition hover:-translate-y-1 hover:border-neutral-400 md:p-9"><div className="flex items-start justify-between"><span className="text-xs font-bold tracking-[.18em] text-neutral-400">{g.number} / {g.tag}</span><span className="text-2xl transition group-hover:translate-x-1">↗</span></div><h2 className="mt-10 text-2xl font-bold tracking-tight md:text-3xl">{g.name}</h2><p className="mt-3 text-neutral-600">{g.detail}</p><p className="mt-8 text-sm font-bold">Play today’s puzzle →</p></Link>)}</div>
 <footer className="mt-16 flex flex-col gap-2 border-t border-neutral-200 pt-5 text-xs text-neutral-500 sm:flex-row sm:justify-between"><span>Made for the joy of figuring things out.</span><Link href="/admin" className="hover:text-black">Puzzle admin</Link></footer></section></main>;
}
