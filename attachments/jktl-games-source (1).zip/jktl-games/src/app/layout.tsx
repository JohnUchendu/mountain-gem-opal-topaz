import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: { default: "JKTL Games — A little daily brain exercise", template: "%s | JKTL Games" },
  description: "Daily word puzzles and playful challenges from JKTL Games.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL || "http://localhost:3000"),
  manifest: "/manifest.webmanifest",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
