import { GameHeader } from "@/components/shared/game-header";
import { DailyRiddleGame } from "@/components/games/daily-riddle-game";
export default function Page(){return <main className="min-h-screen"><GameHeader/><DailyRiddleGame/></main>}
