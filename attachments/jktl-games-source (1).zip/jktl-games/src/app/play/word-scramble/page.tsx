import { GameHeader } from "@/components/shared/game-header";
import { WordScrambleGame } from "@/components/games/word-scramble-game";
export default function Page(){return <main className="min-h-screen"><GameHeader/><WordScrambleGame/></main>}
