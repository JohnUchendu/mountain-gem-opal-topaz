import { GameHeader } from "@/components/shared/game-header";
import { WordGuessGame } from "@/components/games/word-guess-game";

export default function WordGuessPage() {
  return <main className="min-h-screen"><GameHeader /><WordGuessGame /></main>;
}
