import { GameHeader } from "@/components/shared/game-header";
import { WordGroupsGame } from "@/components/games/word-groups-game";

export default function WordGroupsPage() {
  return <main className="min-h-screen"><GameHeader /><WordGroupsGame /></main>;
}
