import { NextResponse } from "next/server";
import { query } from "@/lib/db";

export const runtime = "nodejs";

export async function GET() {
  const date = new Intl.DateTimeFormat("en-CA", {
    timeZone: "Africa/Lagos", year: "numeric", month: "2-digit", day: "2-digit",
  }).format(new Date());
  try {
    const result = await query(
      `SELECT game_type, puzzle_date, title, instructions, puzzle_data
       FROM daily_challenges
       WHERE published = TRUE AND puzzle_date = $1::date
       ORDER BY game_type`,
      [date],
    );
    return NextResponse.json({ date, challenges: result.rows });
  } catch (error) {
    console.error("Unable to load challenges", error);
    return NextResponse.json({ error: "Could not load today’s puzzles. Check database setup." }, { status: 500 });
  }
}
