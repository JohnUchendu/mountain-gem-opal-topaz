import { NextResponse } from "next/server";
import { query } from "@/lib/db";
import { scoreGuess } from "@/lib/games";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const body = await request.json() as { guess?: unknown; date?: unknown };
    const guess = typeof body.guess === "string" ? body.guess.trim().toUpperCase() : "";
    const date = typeof body.date === "string" ? body.date : "";
    if (!/^[A-Z]{5}$/.test(guess) || !/^\d{4}-\d{2}-\d{2}$/.test(date)) {
      return NextResponse.json({ error: "Enter a five-letter word." }, { status: 400 });
    }
    const result = await query<{ answer_data: { answer: string; allowedWords?: string[] } }>(
      `SELECT answer_data FROM daily_challenges
       WHERE game_type = 'word_guess' AND puzzle_date = $1::date AND published = TRUE LIMIT 1`,
      [date],
    );
    const puzzle = result.rows[0]?.answer_data;
    if (!puzzle?.answer) return NextResponse.json({ error: "No published Word Guess puzzle for today." }, { status: 404 });
    if (puzzle.allowedWords && !puzzle.allowedWords.includes(guess) && guess !== puzzle.answer) {
      return NextResponse.json({ error: "That word is not in the accepted word list." }, { status: 400 });
    }
    return NextResponse.json({ guess, marks: scoreGuess(guess, puzzle.answer), solved: guess === puzzle.answer });
  } catch (error) {
    console.error("Guess validation failed", error);
    return NextResponse.json({ error: "Unable to check that guess." }, { status: 500 });
  }
}
