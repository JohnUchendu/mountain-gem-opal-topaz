import { NextResponse } from "next/server";
import { query } from "@/lib/db";

export const runtime = "nodejs";

export async function POST(request: Request) {
  try {
    const body = await request.json() as { date?: unknown; words?: unknown };
    const date = typeof body.date === "string" ? body.date : "";
    const words = Array.isArray(body.words) ? body.words.filter((w): w is string => typeof w === "string") : [];
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || words.length !== 4) {
      return NextResponse.json({ error: "Select four words." }, { status: 400 });
    }
    const result = await query<{ answer_data: { groups: { label: string; color: string; words: string[] }[] } }>(
      `SELECT answer_data FROM daily_challenges
       WHERE game_type = 'word_groups' AND puzzle_date = $1::date AND published = TRUE LIMIT 1`,
      [date],
    );
    const groups = result.rows[0]?.answer_data?.groups;
    if (!groups) return NextResponse.json({ error: "No published Word Groups puzzle for today." }, { status: 404 });
    const matched = groups.find((g) => g.words.length === 4 && g.words.every((w) => words.includes(w)));
    return NextResponse.json(matched ? { correct: true, group: matched.label, color: matched.color } : { correct: false });
  } catch (error) {
    console.error("Group check failed", error);
    return NextResponse.json({ error: "Unable to check those words." }, { status: 500 });
  }
}
