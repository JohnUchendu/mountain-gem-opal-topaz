import { readFile } from "node:fs/promises";
import { pool, query } from "../src/lib/db";

async function main() {
  const schema = await readFile(new URL("../db/schema.sql", import.meta.url), "utf8");
  await query(schema);
  console.log("Database schema created.");
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
}).finally(async () => {
  await pool.end();
});
