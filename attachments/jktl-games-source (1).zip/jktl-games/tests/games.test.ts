import { describe, expect, it } from "vitest";
import { scoreGuess, validateGroupPuzzle } from "../src/lib/games";

describe("scoreGuess", () => {
  it("marks correct, present and absent letters", () => {
    expect(scoreGuess("TALON", "PLANT")).toEqual(["present", "present", "present", "absent", "present"]);
  });

  it("handles duplicate letters without over-counting", () => {
    expect(scoreGuess("ALLEY", "APPLE")).toEqual(["correct", "present", "absent", "present", "absent"]);
  });
});

describe("validateGroupPuzzle", () => {
  it("accepts four disjoint groups covering 16 words", () => {
    const groups = [
      { label: "A", color: "#eee", words: ["A1","A2","A3","A4"] },
      { label: "B", color: "#eee", words: ["B1","B2","B3","B4"] },
      { label: "C", color: "#eee", words: ["C1","C2","C3","C4"] },
      { label: "D", color: "#eee", words: ["D1","D2","D3","D4"] },
    ];
    expect(validateGroupPuzzle({ groups, words: groups.flatMap((g) => g.words) })).toBe(true);
  });
});
