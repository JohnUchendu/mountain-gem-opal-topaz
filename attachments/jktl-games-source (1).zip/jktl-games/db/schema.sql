CREATE TABLE IF NOT EXISTS daily_challenges (
  id BIGSERIAL PRIMARY KEY,
  game_type TEXT NOT NULL CHECK (game_type IN ('word_guess', 'word_groups', 'word_scramble', 'daily_riddle')),
  puzzle_date DATE NOT NULL,
  title TEXT NOT NULL,
  instructions TEXT NOT NULL DEFAULT '',
  puzzle_data JSONB NOT NULL,
  answer_data JSONB NOT NULL,
  published BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (game_type, puzzle_date)
);

CREATE TABLE IF NOT EXISTS players (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  display_name TEXT,
  email TEXT UNIQUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS game_results (
  id BIGSERIAL PRIMARY KEY,
  player_id UUID REFERENCES players(id) ON DELETE SET NULL,
  guest_id TEXT,
  game_type TEXT NOT NULL CHECK (game_type IN ('word_guess', 'word_groups', 'word_scramble', 'daily_riddle')),
  puzzle_date DATE NOT NULL,
  completed BOOLEAN NOT NULL DEFAULT FALSE,
  score INTEGER NOT NULL DEFAULT 0,
  guesses JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE (guest_id, game_type, puzzle_date)
);

CREATE INDEX IF NOT EXISTS daily_challenges_published_date_idx
  ON daily_challenges (published, puzzle_date DESC);
CREATE INDEX IF NOT EXISTS game_results_date_type_idx
  ON game_results (puzzle_date, game_type);


-- Migration-safe update for existing databases.
ALTER TABLE daily_challenges DROP CONSTRAINT IF EXISTS daily_challenges_game_type_check;
ALTER TABLE daily_challenges ADD CONSTRAINT daily_challenges_game_type_check CHECK (game_type IN ('word_guess', 'word_groups', 'word_scramble', 'daily_riddle'));
